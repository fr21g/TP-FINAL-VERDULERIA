<?php
include_once('../../configuracion.php');
include_once('../estructura/cabeceraNueva.php');

?>
 <!-- Start Slider -->
 <div id="slides-shop" class="cover-slides">
        <ul class="slides-container">
            <li class="text-center">
                <img src="../images/banner-01.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>BIENVENIDO A!! <br> Verduleria los tres Rabanitos</strong></h1>
                            <p class="m-b-40">Frutas y verduras frescas<br> Gran variedad de productos</p>
                            <p><a class="btn hvr-hover" href="#">Home</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li class="text-center">
                <img src="../images/banner-02.jpg" alt="">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="m-b-20"><strong>DESCUENTOS! <br> Exclusivos a clientes</strong></h1>
                           
                        </div>
                    </div>
                </div>
            </li>
            
        </ul>
        <div class="slides-navigation">
            <a href="#" class="next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
            <a href="#" class="prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
        </div>
    </div>
    <!-- End Slider -->

   





<?php
include_once ("../estructura/pie.php");




?>